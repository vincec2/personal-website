// ----- SCREEN / FADE -----
const homeScreen = document.getElementById("homeScreen");
const gameScreen = document.getElementById("gameScreen");
const startBtn = document.getElementById("startBtn");
const fade = document.getElementById("fade");

// ----- GAME ELEMENTS -----
const world = document.getElementById("world");
const playerEl = document.getElementById("player");
const npcEl = document.getElementById("npc");
const talkPrompt = document.getElementById("talkPrompt");
const npcBubble = document.getElementById("npcBubble");
const npcChoices = document.getElementById("npcChoices");
const spritesLayer = document.querySelector(".sprites-layer");
let centerActive = false;

// ----- OVERLAY + REWARD UI -----
const envelopeBtn = document.getElementById("envelopeBtn");
const overlay = document.getElementById("overlay");
const openBtn = document.getElementById("openBtn");
const closeBtn = document.getElementById("closeBtn");
const desc = document.getElementById("desc");

function openOverlay() {
  overlay.classList.add("is-open");
  overlay.setAttribute("aria-hidden", "false");
  desc.hidden = true;
  openBtn.textContent = "Open";
  closeBtn.focus();
}

function closeOverlay() {
  overlay.classList.remove("is-open");
  overlay.setAttribute("aria-hidden", "true");
}

function toggleOpen() {
  const isHidden = desc.hidden;
  desc.hidden = !isHidden;
  openBtn.textContent = isHidden ? "Close Letter" : "Open";
}

// Envelope -> Item obtained overlay
envelopeBtn.addEventListener("click", openOverlay);
closeBtn.addEventListener("click", closeOverlay);
openBtn.addEventListener("click", toggleOpen);

// Click outside panel closes
overlay.addEventListener("click", (e) => {
  if (e.target === overlay) closeOverlay();
});

// Esc closes
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && overlay.classList.contains("is-open")) {
    closeOverlay();
  }
});

const gameOverEl = document.getElementById("gameOver");
let gameOverActive = false;

function triggerRewardEnvelope() {
  // show center
  envelopeBtn.classList.remove("is-hidden");
  envelopeBtn.classList.remove("is-docked");
  envelopeBtn.classList.add("is-flying");

  // IMPORTANT: don't let clicking it open the letter yet
  envelopeBtn.style.pointerEvents = "none";

  rewardAwaitingClick = true;
}

function dockRewardEnvelope() {
  envelopeBtn.classList.add("is-docked");

  // when transition ends, it becomes clickable in the corner
  envelopeBtn.addEventListener(
    "transitionend",
    () => {
      envelopeBtn.classList.remove("is-flying");
      envelopeBtn.style.pointerEvents = "auto";
    },
    { once: true }
  );
}

function triggerGameOver() {
  if (gameOverActive) return;
  gameOverActive = true;

  // end dialogue + stop input
  endDialogue();

  // fade to black using existing fade layer
  fade.classList.add("is-on");

  // show "GAME OVER" text after fade is mostly in
  gameOverEl.classList.remove("is-hidden");
  setTimeout(() => gameOverEl.classList.add("is-on"), 520);
}

// ---- SPRITESHEET SETTINGS (PLAYER) ----
// Player sheet: 4 columns x 8 rows
const PLAYER_COLS = 4;
const PLAYER_ROWS = 8;

// row indices (0-based)
const ROW_IDLE = 0;   // first row
const ROW_RIGHT = 1;  // second row
const ROW_LEFT = 7;   // last row

// Timing base (many exports use 60 ticks/sec)
const TICK_MS = 1000 / 60;

const walkAnim = {
  frameW: 32,
  frameH: 40,
  durations: [8, 10, 8, 10], // 4 frames across
};

// ----- PLAYER SWING (sswing) -----
const playerSwingSheet = {
  url: "assets/sswing.png",
  cols: 9,
  rows: 8,
  frameW: 32,
  frameH: 40,
};

const playerSwingAnim = {
  durationTicks: 6, // tweak speed (lower=faster)
};

let playerMode = "walk"; // "walk" | "sswing"
let swingActive = false;

let swingFrame = 0;
let swingTimerMs = 0;

// Swing direction row (locked when the swing starts)
let swingRow = ROW_RIGHT;

function applyPlayerSwingSheet() {
  playerMode = "sswing";
  swingFrame = 0;
  swingTimerMs = 0;
  walking = false;

  // Lock swing to the last facing direction so we don't cycle through all 8 rows
  swingRow = lastFacingRow;

  playerEl.style.backgroundImage = `url("${playerSwingSheet.url}")`;
  playerEl.style.backgroundSize = `${playerSwingSheet.cols * playerSwingSheet.frameW}px ${playerSwingSheet.rows * playerSwingSheet.frameH}px`;
  const yOffset = -swingRow * playerSwingSheet.frameH;
  playerEl.style.backgroundPosition = `0px ${yOffset}px`;
}


// Apply player frame size + slicing
playerEl.style.width = walkAnim.frameW + "px";
playerEl.style.height = walkAnim.frameH + "px";
playerEl.style.backgroundSize = `${PLAYER_COLS * walkAnim.frameW}px ${PLAYER_ROWS * walkAnim.frameH}px`;

// ---- NPC spritesheets ----
// IMPORTANT: keep the NPC element's "viewport" consistent (32x40 like your base sprite),
// but slice each spritesheet using its *real* frame dimensions.
const NPC_VIEW_W = 32;
const NPC_VIEW_H = 40;

const npcSheets = {
  idle: { url: "assets/pidle.png", cols: 8, rows: 8, frameW: 32, frameH: 40 },
  peat: { url: "assets/peat.png", cols: 4, rows: 1, frameW: 24, frameH: 24 },
  pswing: { url: "assets/pswing.png", cols: 9, rows: 8, frameW: 32, frameH: 40 },
};

// How long the peat animation should play
const PEAT_DURATION_MS = 2000;

// NPC animation speed
const npcAnim = {
  durationTicks: 8, // per-frame ticks (lower = faster)
};

// Scale (must match your CSS sprite scale)
const SCALE = 4;

// NPC vertical offset during peat (CSS px)
const NPC_BASE_BOTTOM = parseFloat(getComputedStyle(npcEl).bottom) || 0;
// positive = higher up (since bottom increases)
const NPC_PEAT_LIFT_PX = 28; // tweak: try 16, 24, 32, etc.

// Keep NPC viewport stable so positioning/collision doesn't shift
npcEl.style.width = NPC_VIEW_W + "px";
npcEl.style.height = NPC_VIEW_H + "px";

// ----- PLAYER ANIMATION STATE -----
let frame = 0;
let frameTimerMs = 0;
let walking = false;
let currentRow = ROW_IDLE;
// Remember the last horizontal facing so swings use the correct direction row
let lastFacingRow = ROW_RIGHT;

// ----- NPC ANIMATION STATE -----
let npcMode = "idle"; // "idle" | "peat" | "pswing"
let npcFrame = 0;
let npcTimerMs = 0;
let peatTimeLeftMs = 0;

// Keep NPC swing on a single direction row (NPC is on the right, facing left)
const NPC_SWING_ROW = ROW_LEFT;

function getNpcPad(mode) {
  const s = npcSheets[mode];

  // Center horizontally in the 32px viewport
  const padX = Math.floor((NPC_VIEW_W - s.frameW) / 2);

  // Bottom-align vertically in the 40px viewport (keeps "feet" on the ground)
  const padY = NPC_VIEW_H - s.frameH;

  return { padX, padY };
}

function applyNpcSheet(mode) {
  npcMode = mode;
  npcFrame = 0;
  npcTimerMs = 0;

  const s = npcSheets[mode];
  const { padX, padY } = getNpcPad(mode);

  npcEl.style.backgroundImage = `url("${s.url}")`;
  npcEl.style.backgroundSize = `${s.cols * s.frameW}px ${s.rows * s.frameH}px`;

  // Start at frame 0, positioned with padding so it sits nicely in the viewport.
  // For pswing, lock to a single direction row so it doesn't cycle through all 8 rows.
  const startRow = (mode === "pswing") ? NPC_SWING_ROW : 0;
  const startX = padX;
  const startY = -startRow * s.frameH + padY;
  npcEl.style.backgroundPosition = `${startX}px ${startY}px`;

  // Make NPC higher during peat animation
  npcEl.style.bottom = `${NPC_BASE_BOTTOM + (mode === "peat" ? NPC_PEAT_LIFT_PX : 0)}px`;

}

function triggerPeatAnim() {
  // don't restart if already playing
  if (npcMode === "peat") return;

  peatTimeLeftMs = PEAT_DURATION_MS;
  applyNpcSheet("peat");
}

function updateNpcAnimation(dtMs) {
  // If we're in dialogue, force peat (BUT don't override pswing), and DO NOT tick down peat's timer.
  if (npcPeatLocked && npcMode !== "pswing") {
    if (npcMode !== "peat") applyNpcSheet("peat");
  } else {
    // normal peat timer behavior
    if (npcMode === "peat") {
      peatTimeLeftMs -= dtMs;
      if (peatTimeLeftMs <= 0) {
        applyNpcSheet("idle");
        return;
      }
    }
  }

  npcTimerMs += dtMs;
  const frameDurationMs = npcAnim.durationTicks * TICK_MS;

  if (npcTimerMs >= frameDurationMs) {
    npcTimerMs -= frameDurationMs;

    const s = npcSheets[npcMode];
    const isSwing = npcMode === "pswing";
    const totalFrames = isSwing ? s.cols : (s.cols * s.rows);

    npcFrame = (npcFrame + 1) % totalFrames;

    const col = isSwing ? npcFrame : (npcFrame % s.cols);
    const row = isSwing ? NPC_SWING_ROW : Math.floor(npcFrame / s.cols);

    const { padX, padY } = getNpcPad(npcMode);

    const xOffset = -col * s.frameW + padX;
    const yOffset = -row * s.frameH + padY;

    npcEl.style.backgroundPosition = `${xOffset}px ${yOffset}px`;
  }
}

const SWING_SCALE_MULT = 2;

function applySpriteScales() {
  const playerMult = (playerMode === "sswing") ? SWING_SCALE_MULT : 1;
  playerEl.style.transform = `scale(${SCALE * playerMult})`;
  playerEl.style.transformOrigin = "bottom left";

  const npcMult = (npcMode === "pswing") ? SWING_SCALE_MULT : 1;
  npcEl.style.transform = `scale(${SCALE * npcMult})`;

  npcEl.style.transformOrigin = (npcMode === "pswing") ? "bottom right" : "bottom left";
}


// ----- MOVEMENT STATE -----
let x = 80; // player position (CSS px within world)
let vx = 0;
const SPEED = 180;

const keys = { left: false, right: false };

function setIdle() {
  walking = false;
  frame = 0;
  frameTimerMs = 0;
  currentRow = ROW_IDLE;

  // idle pose: row 0, col 0
  playerEl.style.backgroundPosition = `0px 0px`;
}

function setWalking(dir) {
  walking = true;
  currentRow = dir > 0 ? ROW_RIGHT : ROW_LEFT;
  lastFacingRow = currentRow;
}

function updatePlayerAnimation(dtMs) {
  // SWING MODE (lock to one direction row and advance only columns)
  if (playerMode === "sswing") {
    swingTimerMs += dtMs;
    const frameDurationMs = playerSwingAnim.durationTicks * TICK_MS;

    if (swingTimerMs >= frameDurationMs) {
      swingTimerMs -= frameDurationMs;

      swingFrame = (swingFrame + 1) % playerSwingSheet.cols;

      const xOffset = -swingFrame * playerSwingSheet.frameW;
      const yOffset = -swingRow * playerSwingSheet.frameH;

      playerEl.style.backgroundPosition = `${xOffset}px ${yOffset}px`;
    }
    return;
  }

  // WALK MODE (your existing behavior)
  if (!walking) return;

  frameTimerMs += dtMs;
  const frameDurationMs = (walkAnim.durations[frame] ?? 8) * TICK_MS;

  if (frameTimerMs >= frameDurationMs) {
    frameTimerMs -= frameDurationMs;
    frame = (frame + 1) % walkAnim.durations.length;

    const xOffset = -frame * walkAnim.frameW;
    const yOffset = -currentRow * walkAnim.frameH;
    playerEl.style.backgroundPosition = `${xOffset}px ${yOffset}px`;
  }
}

function updateMovement(dtMs) {
  let dir = 0;
  if (keys.left) dir -= 1;
  if (keys.right) dir += 1;

  vx = dir * SPEED;

  if (dir !== 0) setWalking(dir);
  else setIdle();

  x += vx * (dtMs / 1000);

  const playerW = walkAnim.frameW * SCALE;
  const worldW = world.clientWidth;

  // normal world bounds
  x = Math.max(0, Math.min(x, worldW - playerW));

  // stop before NPC (simple collision)
  const npcLeft = npcEl.offsetLeft;
  if (dir > 0) {
    const maxXBeforeNpc = npcLeft - playerW;
    x = Math.min(x, maxXBeforeNpc);
  }

  playerEl.style.left = `${x}px`;
}

// ----- TALK ZONE -----
let canTalk = false;
let dialogueActive = false;
let dialogueIndex = 0;
let npcPeatLocked = false;

const DIALOGUE = [
  { type: "text", text: "Welcome!" },
  { type: "text", text: "You must answer this question to receive the ultimate item..." },
  { type: "choice", text: "I love you. Do you love me?", choices: ["Yes", "No"] },

  // YES branch continues here
  { type: "text", text: "Good :)" },
  { type: "text", text: "Here is your reward...", onEnter: triggerRewardEnvelope },
];

let rewardAwaitingClick = false;

function getTranslateX(el) {
  const t = getComputedStyle(el).transform;
  if (!t || t === "none") return 0;

  // matrix(a,b,c,d,tx,ty)
  if (t.startsWith("matrix(")) {
    const parts = t.slice(7, -1).split(",").map(s => parseFloat(s));
    return parts[4] || 0;
  }

  // matrix3d(..., tx, ty, tz)  tx is index 12
  if (t.startsWith("matrix3d(")) {
    const parts = t.slice(9, -1).split(",").map(s => parseFloat(s));
    return parts[12] || 0;
  }

  return 0;
}

function centerSpritesBetweenPlayerAndNpc() {
  if (!spritesLayer) return;

  const worldRect = world.getBoundingClientRect();
  const pRect = playerEl.getBoundingClientRect();
  const nRect = npcEl.getBoundingClientRect();

  const worldCenterX = worldRect.left + worldRect.width / 2;
  const midX = (pRect.left + pRect.width / 2 + nRect.left + nRect.width / 2) / 2;

  // dx is the *delta* needed from the CURRENT position
  const dx = worldCenterX - midX;

  // accumulate it onto the existing translateX
  const currentTx = getTranslateX(spritesLayer);
  spritesLayer.style.transform = `translateX(${currentTx + dx}px)`;

  centerActive = true;
}

function resetSpriteLayerCentering() {
  if (!spritesLayer) return;
  spritesLayer.style.transform = "";
  centerActive = false;
}

function startSwingSequence() {
  if (swingActive) return;
  swingActive = true;

  // Stop forcing the NPC to stay in peat during the dialogue
  // so pswing isn't immediately overridden.
  npcPeatLocked = false;

  // stop movement input immediately
  keys.left = false;
  keys.right = false;

  // swap both sheets
  applyPlayerSwingSheet();
  applyNpcSheet("pswing");
  centerSpritesBetweenPlayerAndNpc();
}

function showNpcBubblePersistent(text) {
  npcBubble.textContent = text;
  bubbleUntilMs = Number.POSITIVE_INFINITY; // never auto-hides
  npcBubble.classList.remove("is-hidden");
}

function hideNpcChoices() {
  npcChoices.classList.add("is-hidden");
}

function showNpcChoices() {
  npcChoices.classList.remove("is-hidden");
}

let lastStepShown = -1;

function showDialogueStep() {
  const step = DIALOGUE[dialogueIndex];

  hideNpcChoices();
  showNpcBubblePersistent(step.text);

  // run step hooks once
  if (dialogueIndex !== lastStepShown) {
    lastStepShown = dialogueIndex;
    if (typeof step.onEnter === "function") step.onEnter();
  }

  if (step.type === "choice") {
    showNpcChoices();
  }
}

function startDialogue() {
  dialogueActive = true;
  dialogueIndex = 0;

  // keep peat running during convo
  npcPeatLocked = true;
  if (npcMode !== "peat") applyNpcSheet("peat");

  talkPrompt.classList.add("is-hidden");
  showDialogueStep();
}

function endDialogue() {
  dialogueActive = false;
  npcPeatLocked = false;

  hideNpcBubble();
  hideNpcChoices();

  // DON'T override pswing if we're in the swing sequence
  if (!swingActive) {
    applyNpcSheet("idle");
  }
}

function advanceDialogue() {
  if (!dialogueActive) return;

  const step = DIALOGUE[dialogueIndex];
  if (step.type === "choice") return; // must choose yes/no

  dialogueIndex += 1;
  if (dialogueIndex >= DIALOGUE.length) {
    endDialogue();
    return;
  }
  showDialogueStep();
}


function updateTalkZone() {
  const playerW = walkAnim.frameW * SCALE;
  const playerRight = x + playerW;

  const npcLeft = npcEl.offsetLeft;
  const threshold = 6;

  canTalk = playerRight >= (npcLeft - threshold);
  talkPrompt.classList.toggle("is-hidden", !canTalk);
}

let bubbleUntilMs = 0;
let bubbleText = "Quiz time.";

function showNpcBubble(text, durationMs = 1800) {
  bubbleText = text;
  npcBubble.textContent = text;
  bubbleUntilMs = performance.now() + durationMs;
  npcBubble.classList.remove("is-hidden");
}

function hideNpcBubble() {
  npcBubble.classList.add("is-hidden");
}

function positionNpcBubble() {
  // if hidden, no need to position
  if (!bubbleUntilMs || npcBubble.classList.contains("is-hidden")) return;

  const worldRect = world.getBoundingClientRect();
  const npcRect = npcEl.getBoundingClientRect();

  // place bubble centered above NPC
  const x = (npcRect.right - worldRect.left) - 6; // anchor near npc's right edge
  const y = (npcRect.top - worldRect.top) + 20; // lift above head (tweak)

  npcBubble.style.left = `${x}px`;
  npcBubble.style.top = `${y}px`;
  const bubbleRect = npcBubble.getBoundingClientRect();
  const worldLeft = worldRect.left;

  if (bubbleRect.left < worldLeft + 6) {
    const overflow = (worldLeft + 6) - bubbleRect.left;
    npcBubble.style.left = `${x + overflow}px`;
  }
}

function positionNpcChoices() {
  if (npcChoices.classList.contains("is-hidden")) return;

  const worldRect = world.getBoundingClientRect();
  const bubbleRect = npcBubble.getBoundingClientRect();

  // align choices under the bubble, anchored to bubble's right edge
  const x = (bubbleRect.right - worldRect.left) - 6;
  const y = (bubbleRect.bottom - worldRect.top) + 10;

  npcChoices.style.left = `${x}px`;
  npcChoices.style.top = `${y}px`;

  // clamp so it doesn't go off the left side
  const choicesRect = npcChoices.getBoundingClientRect();
  if (choicesRect.left < worldRect.left + 6) {
    const overflow = (worldRect.left + 6) - choicesRect.left;
    npcChoices.style.left = `${x + overflow}px`;
  }
}

function updateBubble() {
  if (!bubbleUntilMs) return;

  // If using "persistent", bubbleUntilMs is Infinity, so it won't auto-hide.
  if (performance.now() >= bubbleUntilMs) {
    bubbleUntilMs = 0;
    hideNpcBubble();
    hideNpcChoices();
    return;
  }

  positionNpcBubble();
  positionNpcChoices(); // <-- add this
}

// ----- GAME LOOP -----
let lastT = null;

function loop(t) {
  if (lastT == null) lastT = t;
  const dt = t - lastT;
  lastT = t;

  // Only allow movement + talk prompt when NOT in dialogue and NOT swinging
  if (!dialogueActive && !swingActive) {
    updateMovement(dt);
    updateTalkZone();
  } else {
    talkPrompt.classList.add("is-hidden");
  }

  // Always animate sprites
  updatePlayerAnimation(dt);
  updateNpcAnimation(dt);
  applySpriteScales();
  if (swingActive) centerSpritesBetweenPlayerAndNpc();

  // Always keep bubble/choices positioned
  updateBubble();

  requestAnimationFrame(loop);
}

// ----- INPUT -----
window.addEventListener("keydown", (e) => {
  if (gameOverActive) return;
  if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") keys.left = true;
  if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") keys.right = true;
  if ((e.key === "e" || e.key === "E") && canTalk && !dialogueActive) startDialogue();
});

window.addEventListener("mousedown", (e) => {
  if (gameOverActive) return;
  if (e.button !== 0) return; // left click only
  if (!dialogueActive) return;

  // don't advance when clicking on the choice buttons
  if (e.target.closest("#npcChoices")) return;
  // If reward is waiting for click: dock + start swings, then continue
  if (rewardAwaitingClick) {
    rewardAwaitingClick = false;
    dockRewardEnvelope();
    startSwingSequence();
  }

  advanceDialogue();
});

// YES/NO selection
npcChoices.addEventListener("click", (e) => {
  if (gameOverActive) return;
  const btn = e.target.closest(".npc-choice");
  if (!btn) return;

  const choice = btn.dataset.choice; // "yes" or "no"
  handleNpcChoice(choice);
});

function handleNpcChoice(choice) {
  if (!dialogueActive) return;

  const step = DIALOGUE[dialogueIndex];
  if (!step || step.type !== "choice") return;

  hideNpcChoices();

  if (choice === "no") {
    triggerGameOver();
    return;
  }

  // YES: advance to next step ("good :)")
  dialogueIndex += 1;
  showDialogueStep();
}

window.addEventListener("keyup", (e) => {
  if (e.key === "ArrowLeft" || e.key === "a" || e.key === "A") keys.left = false;
  if (e.key === "ArrowRight" || e.key === "d" || e.key === "D") keys.right = false;
});


// ----- START FLOW WITH FADE -----
function showGameScreenWithFade() {
  fade.classList.add("is-on");

  setTimeout(() => {
    homeScreen.classList.add("is-hidden");
    gameScreen.classList.remove("is-hidden");

    // player idle immediately
    setIdle();

    // npc idle immediately (and anim starts looping)
    applyNpcSheet("idle");

    // start loop once visible
    requestAnimationFrame(loop);

    // fade back out
    requestAnimationFrame(() => fade.classList.remove("is-on"));
  }, 520);
}

startBtn.addEventListener("click", showGameScreenWithFade);